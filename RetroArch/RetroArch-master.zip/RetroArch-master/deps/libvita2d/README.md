## VITA2DLIB

Simple and Fast (using the GPU) 2D library for the PSVita

Depends on [vita portlibs] (https://github.com/xerpi/vita_portlibs)
