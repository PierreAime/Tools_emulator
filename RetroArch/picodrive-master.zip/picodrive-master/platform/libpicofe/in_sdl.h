int in_sdl_init(const struct in_pdata *pdata, void (*handler)(void *event));
