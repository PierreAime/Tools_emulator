#include "plat.h"

struct plat_target plat_target;

int plat_target_init(void)
{
	return 0;
}

void plat_target_finish(void)
{
}

void plat_target_setup_input(void)
{
}
