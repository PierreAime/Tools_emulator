
extern volatile unsigned short *memregs;
extern volatile unsigned int   *memregl;
extern int memdev;

int pollux_get_real_snd_rate(int req_rate);
