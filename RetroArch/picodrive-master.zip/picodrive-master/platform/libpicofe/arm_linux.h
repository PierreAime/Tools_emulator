extern void cache_flush_d_inval_i(void *start_addr, void *end_addr);
