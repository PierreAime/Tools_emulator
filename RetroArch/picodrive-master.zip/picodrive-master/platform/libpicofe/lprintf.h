#ifdef __cplusplus
extern "C" {
#endif

extern void lprintf(const char *fmt, ...);

#ifdef __cplusplus
}
#endif

