int gl_platform_init(void **display, void **window, int *quirks);
void gl_platform_finish(void);
