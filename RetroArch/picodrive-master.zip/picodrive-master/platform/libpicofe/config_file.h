#include <stdio.h>

void config_write_keys(FILE *f);
void config_read_keys(const char *cfg);
