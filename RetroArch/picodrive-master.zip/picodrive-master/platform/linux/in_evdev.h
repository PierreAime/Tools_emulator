
struct in_default_bind;
extern int in_evdev_allow_abs_only;

void in_evdev_init(const struct in_default_bind *defbinds);
