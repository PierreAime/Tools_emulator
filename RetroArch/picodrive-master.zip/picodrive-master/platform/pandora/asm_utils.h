
void clut_line2x2(void *dest, const void *src, const unsigned short *pal, int pixels_mask);
void clut_line3x2(void *dest, const void *src, const unsigned short *pal, int pixels_mask);
