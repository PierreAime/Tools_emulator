#ifndef RL_VERSION_H
#define RL_VERSION_H

extern const char* rl_gitstamp;
extern const char* rl_githash;

#endif /* RL_VERSION_H */
