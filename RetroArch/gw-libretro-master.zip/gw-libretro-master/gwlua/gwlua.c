#include <gwlua.h>

#include <string.h>

#include <gwrom.h>
#include <bsreader.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#if 0
static void dump_stack( lua_State* L, const char* title )
{
  printf( "================================\n%s\n", title );
  int top = lua_gettop( L );
  int i;
  
  for ( i = 1; i <= top; i++ )
  {
    printf( "%2d %3d ", i, i - top - 1 );
    
    lua_pushvalue( L, i );
    
    switch ( lua_type( L, -1 ) )
    {
    case LUA_TNIL:
      printf( "nil\n" );
      break;
    case LUA_TNUMBER:
      printf( "%e\n", lua_tonumber( L, -1 ) );
      break;
    case LUA_TBOOLEAN:
      printf( "%s\n", lua_toboolean( L, -1 ) ? "true" : "false" );
      break;
    case LUA_TSTRING:
      printf( "\"%s\"\n", lua_tostring( L, -1 ) );
      break;
    case LUA_TTABLE:
      printf( "table\n" );
      break;
    case LUA_TFUNCTION:
      printf( "function\n" );
      break;
    case LUA_TUSERDATA:
      printf( "userdata\n" );
      break;
    case LUA_TTHREAD:
      printf( "thread\n" );
      break;
    case LUA_TLIGHTUSERDATA:
      printf( "light userdata\n" );
      break;
    default:
      printf( "?\n" );
      break;
    }
  }
  
  lua_settop( L, top );
}
#endif

static void* l_alloc( void* ud, void* ptr, size_t osize, size_t nsize )
{
  (void)ud;
  (void)osize;
  
  if ( nsize == 0 )
  {
    if ( ptr )
    {
      gwlua_free( ptr );
    }
    
    return NULL;
  }

  return gwlua_realloc( ptr, nsize );
}

static int l_traceback( lua_State* L )
{
  luaL_traceback( L, L, lua_tostring( L, -1 ), 1 );
  return 1;
}

static int l_pcall( lua_State* L, int nargs, int nres )
{
  lua_pushcfunction( L, l_traceback );
  lua_insert( L, -nargs - 2 );
  
  if ( lua_pcall( L, nargs, nres, -nargs - 2 ) != LUA_OK )
  {
    gwlua_log( "\n==============================\n%s\n------------------------------\n", lua_tostring( L, -1 ) );
    return -1;
  }
  
  return 0;
}

void register_functions( lua_State* L, gwlua_t* state );

static int l_create( lua_State* L )
{
  gwlua_t* state = (gwlua_t*)lua_touserdata( L, 1 );
  
  register_functions( L, state );
  
  gwrom_entry_t entry;
  int error = gwrom_find( &entry, state->rom, "main.bs" );
  
  if ( error != GWROM_OK )
  {
    return luaL_error( L, "%s", gwrom_error_message( error ) );
  }
  
  void* bs = bsnew( entry.data );
  
  if ( !bs )
  {
    return luaL_error( L, "out of memory allocating the bs reader" );
  }
  
  if ( lua_load( L, bsread, bs, "main.lua", "t" ) != LUA_OK )
  {
    free( bs );
    return lua_error( L );
  }
  
  free( bs );
  
  lua_call( L, 0, 1 );
  gwlua_ref_create( L, -1, &state->tick_ref );
  return 0;
}

int gwlua_create( gwlua_t* state, gwrom_t* rom )
{
  static const luaL_Reg lualibs[] =
  {
    { "_G", luaopen_base },
    { LUA_LOADLIBNAME, luaopen_package },
    { LUA_COLIBNAME, luaopen_coroutine },
    { LUA_TABLIBNAME, luaopen_table },
    // { LUA_IOLIBNAME, luaopen_io }, // remove because of tmpfile
    // { LUA_OSLIBNAME, luaopen_os }, // remove because of system
    { LUA_STRLIBNAME, luaopen_string },
    { LUA_MATHLIBNAME, luaopen_math },
    { LUA_UTF8LIBNAME, luaopen_utf8 },
    { LUA_DBLIBNAME, luaopen_debug },
  };

  state->L = lua_newstate( l_alloc, NULL );
  
  if ( !state->L )
  {
    return -1;
  }
  
#ifndef NDEBUG
  lua_pushboolean( state->L, 1 );
  lua_setglobal( state->L, "_DEBUG" );
#endif
  
  int i;
  
  for ( i = 0; i < sizeof( lualibs ) / sizeof( lualibs[ 0 ] ); i++ )
  {
    luaL_requiref( state->L, lualibs[ i ].name, lualibs[ i ].func, 1 );
    lua_pop( state->L, 1 );
  }
  
  state->rom = rom;
  state->width = state->height = 0;
  state->screen = NULL;
  state->help = 0;
  state->now = 0;
  memset( (void*)state->input, 0, sizeof( state->input ) );
  state->tick_ref = LUA_NOREF;
  
  lua_pushcfunction( state->L, l_create );
  lua_pushlightuserdata( state->L, (void*)state );
  
  if ( l_pcall( state->L, 1, 0 ) )
  {
    lua_close( state->L );
    state->L = NULL;
    return -1;
  }
  
  return 0;
}

void gwlua_destroy( gwlua_t* state )
{
  if ( state->L )
  {
    lua_close( state->L );
    state->L = NULL;
  }
}

int gwlua_reset( gwlua_t* state )
{
  gwrom_t* rom = state->rom;
  gwlua_destroy( state );
  return gwlua_create( state, rom );
}

/*---------------------------------------------------------------------------*/

void gwlua_set_button( gwlua_t* state, int button, int pressed )
{
  if ( button != GWLUA_START )
  {
    state->input[ button ] = pressed;
  }
  else
  {
    if ( pressed )
    {
      if ( !state->input[ GWLUA_START ] )
      {
        state->input[ GWLUA_START ] = 1;
        state->help = !state->help;
      }
    }
    else
    {
      state->input[ GWLUA_START ] = 0;
    }
  }
}

/*---------------------------------------------------------------------------*/

void gwlua_tick( gwlua_t* state )
{
  state->now += 16666;
  
  gwlua_ref_get( state->L, state->tick_ref );
  l_pcall( state->L, 0, 0 );
  lua_gc( state->L, LUA_GCSTEP, 0 );
}

/*---------------------------------------------------------------------------*/

uint32_t gwlua_djb2( const char* str )
{
  const uint8_t* aux = (const uint8_t*)str;
  uint32_t hash = 5381;

  while ( *aux )
  {
    hash = ( hash << 5 ) + hash + *aux++;
  }

  return hash;
}

/*---------------------------------------------------------------------------*/

void gwlua_log( const char* format, ... )
{
  va_list args;
  va_start( args, format );
  gwlua_vlog( format, args );
  va_end( args );
}
