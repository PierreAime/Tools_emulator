local M = {}

M.tshiftstate = 0
M.ssleft = 0
M.tacenter = 0

return M
