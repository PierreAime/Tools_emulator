local M = {}

M.pfsoundsample = system.newsound
M.fsound_free = 0
M.fsound_repeat = 1 -- fsound_repeat is a guess
M.fsound_all = {}

return M
