local M = {}

M.timage = system.newimage
M.ttimer = system.newtimer

return M
