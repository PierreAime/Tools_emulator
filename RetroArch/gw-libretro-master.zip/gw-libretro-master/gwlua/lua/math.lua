local math = require 'math'

local M = {}

M.floor = math.floor
M.abs = math.abs

return M
