local M = {}

M.tmousebutton = 0
M.mbleft = 0
M.crhelp = 0
M.crhandpoint = 0
M.crdefault = 0

return M
