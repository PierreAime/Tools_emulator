# gwrom

An archive reader for games.

## Usage

Add gwrom.c and gwrom.h to your project. See gwrom.h for some documentation.