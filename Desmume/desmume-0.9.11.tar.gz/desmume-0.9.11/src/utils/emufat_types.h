#ifndef EMUFAT_TYPES_H
#define EMUFAT_TYPES_H

#include "types.h"

#endif //EMUFAT_TYPES_H
