#ifndef __DESMUME_GTK_MAIN_H__
#define __DESMUME_GTK_MAIN_H__

void Pause();
void Launch();

#endif
