#ifndef EMUFILE_TYPES_H
#define EMUFILE_TYPES_H

#include "types.h"

#endif //EMUFILE_TYPES_H
