GLideN64
========

A new generation, open-source graphics plugin for N64 emulators.
