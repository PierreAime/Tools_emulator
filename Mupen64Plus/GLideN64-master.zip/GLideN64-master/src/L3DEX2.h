#ifndef L3DEX2_H
#define L3DEX2_H
#include "Types.h"

#define L3DEX2_LINE3D				0x08

void L3DEX2_Line3D( u32 w0, u32 w1 );
void L3DEX2_Init();
#endif

