#ifndef F3DGOLDEN_H
#define F3DGOLDEN_H

#define F3D_TRIX	0xB1

void F3DGOLDEN_Init();

void F3D_TriX(u32 w0, u32 w1);

#endif

