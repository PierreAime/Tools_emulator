#ifndef F3DBETA_H
#define F3DBETA_H

#define F3DBETA_TRI2		0xB1
void F3DBETA_Init();

#endif

