#ifndef DEBUG_H
#define DEBUG_H

// TODO Debug log.
#define DebugMsg(A, ...)
#define DebugRSPState(A, ...)

#endif // DEBUG_H
