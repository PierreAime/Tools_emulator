#ifndef F3DEX2MM_H
#define F3DEX2MM_H

void F3DEX2MM_Init();

#endif // F3DEX2M_H
